insert into author(id, name, email) values(1, 'peter', 'peteer@gmail.com');
insert into author(id, name, email) values(2, 'Smith', 'Smith@gmail.com');
insert into author(id, name, email) values(3, 'John', 'John@gmail.com');
insert into author(id, name, email) values(4, 'Banu', 'banu@gmail.com');


insert into post(id, title, description, category, author_id) values(100, 'post title','post text', 'Adventure', 1);
insert into post(id, title, description, category, author_id) values(101, 'spring boot','spring boot and graphQl', 'IT',2);
insert into post(id, title, description, category, author_id) values(102, 'REACT','REACT course', 'IT', 2);
insert into post(id, title, description, category, author_id) values(103, 'JS','JS course', 'IT', 4);
