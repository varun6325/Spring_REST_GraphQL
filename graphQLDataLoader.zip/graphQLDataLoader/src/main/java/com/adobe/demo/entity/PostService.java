package com.adobe.demo.entity;

public interface PostService {

}
