package com.adobe.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphQlDataLoaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphQlDataLoaderApplication.class, args);
	}

}
