package com.example.demo.query;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.example.demo.domain.Product;
import com.example.demo.domain.ProductInStock;

import io.leangen.graphql.annotations.GraphQLArgument;
import io.leangen.graphql.annotations.GraphQLQuery;

@Component
public class ProductQuery {

	/**
	 * Fetching a mock list of a vendor's products in stock
	 *
	 * Invoke with: {productsInStockOfVendor(vendorId: 2){product{name,
	 * description},stockSize}}
	 *
	 * @param vendorId
	 * @return
	 */
	@GraphQLQuery(name = "productsInStockOfVendor")
	public Set<ProductInStock> getProductsInStock(
			@GraphQLArgument(name = "vendorId", description = "Id of vendor.") Long vendorId) {
		Set<ProductInStock> mockResult = new HashSet<>();
		Product product1 = new Product(0L, "MockProduct1", "Product 1 description");
		mockResult.add(new ProductInStock(product1, 10L));
		Product product2 = new Product(1L, "MockProduct2", "Product 2 description");
		mockResult.add(new ProductInStock(product2, 20L));

		return mockResult;
	}
}