package com.example.demo.domain;


import io.leangen.graphql.annotations.GraphQLQuery;

public class ProductInStock {
    private Product product;
    private long stockSize;

    public ProductInStock(){
    }

    public ProductInStock(Product product, long stockSize) {
        this.product = product;
        this.stockSize = stockSize;
    }

    @GraphQLQuery(name = "product")
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @GraphQLQuery(name = "stockSize")
    public long getStockSize() {
        return stockSize;
    }

    public void setStockSize(long stockSize) {
        this.stockSize = stockSize;
    }

    
}