package com.example.demo.domain;

import io.leangen.graphql.annotations.GraphQLQuery;

public class Person {
	 private String firstName;
	    private String lastName;
	    
	    @GraphQLQuery(name = "firstName")
	    public String getFirstName() {
	        return firstName;
	    }

	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    
	    @GraphQLQuery(name = "lastName")
	    public String getLastName() {
	        return lastName;
	    }

	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }

}
